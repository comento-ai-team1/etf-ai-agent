import os


from dotenv import load_dotenv
from langchain.agents import create_agent
from langchain_openai import ChatOpenAI

from agent_tools import ETF_AGENT_TOOLS
from api_tools import EXTERNAL_API_TOOLS

load_dotenv()


OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

if not OPENAI_API_KEY:
    raise RuntimeError(
        ".env 파일에서 OPENAI_API_KEY를 찾지 못했습니다."
    )


SYSTEM_PROMPT = """
너는 ETF 질의응답 챗봇의 메인 오케스트레이터 에이전트다.

사용자의 질문을 분석하고 필요한 전문 도구를 선택해야 한다.

현재 사용할 수 있는 도구는 다음과 같다.

1. search_etf_product
- ETF 상품명 또는 종목코드로 상품 DB를 조회한다.
- 운용사, 자산 유형, 기초지수, 총보수, 위험등급,
  상장일, 구성종목과 자료 출처를 확인할 때 사용한다.
- 종가와 NAV 같은 시세 조회에는 사용하지 않는다.

2. search_faq
- ETF 기본 개념, 거래, 가격 용어, 비용, 분배금,
  구성종목과 투자위험을 설명할 때 사용한다.
- FAQ 검색 결과가 여러 개라면 match_score가 가장 높은
  결과를 우선적으로 사용한다.
- 관련성이 낮은 FAQ 내용을 답변에 섞지 않는다.

3. get_etf_price
- 특정 ETF의 최근 자료 기준일 종가와 NAV를 조회한다.
- 사용자가 종가, 가격, NAV 또는 기준일을 질문할 때 사용한다.
- 조회 결과는 실시간 가격이 아니므로 반드시 자료 기준일을 표시한다.

4. search_etf_disclosure
- 특정 ETF와 관련된 DART 공시 제목과 원문 링크를 조회한다.
- 사용자가 공시, 투자설명서, 일괄신고서 또는 기재정정을
  질문할 때 사용한다.
- 공시 제목만으로 구체적인 변경 내용을 추측하지 않는다.

종가와 공시를 함께 요청하면 get_etf_price와
search_etf_disclosure를 모두 호출해야 한다.

반드시 다음 원칙을 지켜라.

- DB에 저장된 정보만 사실로 사용한다.
- DB에 없는 값은 추측하거나 만들어내지 않는다.
- 자료의 출처와 확인일이 있으면 답변에 표시한다.
- 확인하지 못한 실시간 가격이나 수익률을 말하지 않는다.
- 특정 상품의 매수 또는 매도를 추천하지 않는다.
- 투자 판단은 사용자 본인의 책임이라는 점을 지킨다.
- 초보자가 이해하기 쉬운 한국어로 답변한다.
- 답변은 필요 이상으로 길게 작성하지 않는다.
- 공시 조회 결과에 원문 URL이 있으면 각 공시 제목과 링크를 반드시 함께 표시한다.
- 조회 결과에 포함된 출처 URL을 임의로 생략하지 않는다.
- 이미 조회한 자료를 두고 나중에 제공하겠다고 답하지 않는다.
"""


model = ChatOpenAI(
    model="gpt-5.4-mini",
    api_key=OPENAI_API_KEY,
    use_responses_api=True,
    reasoning_effort="low",
    verbosity="low",
    max_completion_tokens=700,
    max_retries=2,
    store=False,
)


etf_agent = create_agent(
    model=model,
    tools=ETF_AGENT_TOOLS + EXTERNAL_API_TOOLS,
    system_prompt=SYSTEM_PROMPT,
    name="etf_orchestrator",
)


def extract_answer(message):
    """LangChain의 최종 메시지에서 답변 텍스트를 꺼냅니다."""

    content = message.content

    if isinstance(content, str):
        return content

    if isinstance(content, list):
        text_parts = []

        for item in content:
            if isinstance(item, str):
                text_parts.append(item)

            elif isinstance(item, dict):
                text = (
                    item.get("text")
                    or item.get("content")
                    or item.get("output_text")
                )

                if text:
                    text_parts.append(str(text))

        return "\n".join(text_parts)

    return str(content)


def run_etf_agent(question):
    """
    사용자 질문을 LangChain 에이전트에 전달하고
    최종 답변과 사용한 도구 목록을 반환합니다.
    """

    question = question.strip()

    if not question:
        return {
            "answer": "질문을 입력해 주세요.",
            "used_tools": [],
        }

    result = etf_agent.invoke(
        {
            "messages": [
                {
                    "role": "user",
                    "content": question,
                }
            ]
        }
    )

    messages = result.get("messages", [])

    if not messages:
        return {
            "answer": "답변을 생성하지 못했습니다.",
            "used_tools": [],
        }

    used_tools = []

    for message in messages:
        message_type = getattr(message, "type", "")

        if message_type == "tool":
            tool_name = getattr(message, "name", None)

            if tool_name and tool_name not in used_tools:
                used_tools.append(tool_name)

    final_message = messages[-1]
    answer = extract_answer(final_message)

    return {
        "answer": answer,
        "used_tools": used_tools,
    }